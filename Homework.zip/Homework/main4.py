
# 4. Напечатать число А на экране К раз
A = int(input("Введите число A: "))
K = int(input("Введите число K: "))
count = 0
while count < K:
    print(A, end=", ")
    count += 1
print()

