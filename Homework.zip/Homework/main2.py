# 2. Вывести числа от K до 0
K = int(input("Введите число K: "))
while K >= 0:
    print(K, end=" ")
    K -= 1
print()

