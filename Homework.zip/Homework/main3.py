# 3. Вывести числа между двумя числами в порядке возрастания
num_1 = int(input("Введите первое число: "))
num_2 = int(input("Введите второе число: "))
start = min(num_1, num_2) + 1
end = max(num_1, num_2)
while start < end:
    print(start, end=" ")
    start += 1
print()
