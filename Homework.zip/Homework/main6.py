# 6. Посчитать сумму чисел между a и b (a может быть больше b)
a = int(input("Введите число a: "))
b = int(input("Введите число b: "))
sum_numbers = 0
i = b + 1
while i < a:
    sum_numbers += i
    i += 1
print("Сумма чисел между", b, "и", a, ":", sum_numbers)
