# 5. Посчитать сумму чисел между a и b
a = int(input("Введите число a: "))
b = int(input("Введите число b: "))
sum_numbers = 0
i = a + 1
while i < b:
    sum_numbers += i
    i += 1
print("Сумма чисел между", a, "и", b, ":", sum_numbers)


