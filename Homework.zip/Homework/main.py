#Rustam Abdumutalibov

# 1. Отобразить числа от 1 до А
A = int(input("Введите число A: "))
i = 1
while i <= A:
    print(i, end=" ")
    i += 1
print()

