# 1. Посчитать количество чисел от 1 до А, кратных 4
A = int(input("Введите число A: "))
count = 0
for i in range(1, A + 1):
    if i % 4 == 0:
        count += 1
print("Количество чисел от 1 до", A, "кратных 4:", count)

# 2. Вывести полиндромные числа между двумя введенными числами
def is_palindrome(num):
    return str(num) == str(num)[:-1]

num_1 = int(input("Введите первое число: "))
num_2 = int(input("Введите второе число: "))

palindromes = []
for num in range(min(num_1, num_2), max(num_1, num_2) + 1):
    if is_palindrome(num):
        palindromes.append(num)

print("Полиндромные числа между", min(num_1, num_2), "и", max(num_1, num_2), ":", palindromes)
